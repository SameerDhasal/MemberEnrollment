// const sql = require('./conn');

// const emptyOrRows = function (rows) {
//   if (!rows) {
//     return [];
//   }
//   return rows;
// }

// // Get Account Name
// async function getBenefitplans(data) {

//   sql.connect(function (err) {
//     if (err) {
//       console.error('Error connecting: ' + err.stack);
//       return;
//     }
//   });

//   function getBp() {
//     sql.query('SELECT Account FROM policy;', function (error, results) {
//       if (error) throw reject(error);
//       resolve(results);
//     });
    
//     let bpData = data;
//     console.log(bpData);
//   }

//   const cols = await getBp();
//   const dataSet = emptyOrRows(cols);

//   // sql.end();

//   return dataSet;
// }

// module.exports = {
//     getBenefitplans
// }