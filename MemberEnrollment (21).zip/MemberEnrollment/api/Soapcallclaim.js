const oracleconnection = require('./conn');
const services = require('./services');
//import { services } from ('./services');
var DomParser = require('dom-parser');
const oracledb = require('oracledb');
const soapRequest = require('easy-soap-request');
const { copySync } = require('file-system');
const today = new Date();

const year = today.getFullYear();
const month = today.getMonth() + 1; // Months are zero-indexed
const day = today.getDate();
const month2Digit2 = month < 10 ? "0" + month : month;
const daysDigit2 = day < 10 ? "0" + day : day;
// Format the date into the desired format.
const formattedDate = `${year}-${month2Digit2}-${daysDigit2}`;
const formattedDate1 = today.toISOString();
console.log(formattedDate);

async function proclaimsoapUI(memberid,diag,arrayforclaimline,otherfields,supdata,supplierdetails,memberandsubdata) {

	var tempstring='';
	let claim_Id ='';
	
   for(k=0;k<arrayforclaimline.length;k++)
	 {
		   var claimline=
		   `<serviceLineItem>
			<originalLineNumber>${k+1}</originalLineNumber>
			<startDate>2023-04-16</startDate>
			<endDate>2023-04-16</endDate>
			<placeOfServiceCode>${arrayforclaimline[k].POS}</placeOfServiceCode>
			<serviceCode>${arrayforclaimline[k].Servicecode}</serviceCode>
			<serviceFee>${arrayforclaimline[k].BillAmount}</serviceFee>
			<serviceUnitCount>1</serviceUnitCount>
			<otherRenderingProviderId>${arrayforclaimline[k].PractitionerID}</otherRenderingProviderId>
			<renderingProviderCLIAId/>
			<diagnosisCodePointers>
			<diagnosisCodePointer>1</diagnosisCodePointer>
			</diagnosisCodePointers>
			<serviceFacilityLocation>
			<locationName>${supdata.arraysupp[0].sublocation}</locationName>
			<streetAddress>${supdata.arraysupp[0].add}</streetAddress>
			<cityName>${supdata.arraysupp[0].city}</cityName>
			<stateCode>${supdata.arraysupp[0].citycode}</stateCode>
			<zipCode>${supdata.arraysupp[0].zipcode}</zipCode>
			<countryCode>
			<countryCode>US</countryCode>
			</countryCode>
			<npi>${supdata.arraysupp[0].npi}</npi>
			</serviceFacilityLocation>
			</serviceLineItem>`
						//console.log(claimline);
			tempstring = tempstring.concat("\n", claimline);
	 }
	 //console.log(tempstring);
	//}
	const url = 'http://100.112.45.153:8181/connector/services/v4/ProfessionalClaim';
	const sampleHeaders = {
		'Content-Type': 'text/xml;charset=UTF-8',
		'soapAction': 'http://healthedge.com/submit',
		'Authorization': 'Basic Y29ubmVjdG9yOkNvbm5lY3RvcjEyMw=='
	};
	const claimnumber= (async () => {
		const xml = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:prof="http://www.healthedge.com/connector/schema/claim/professional">
		<soapenv:Header/>
		<soapenv:Body>
			<prof:professionalClaim>
				<receiptDate>${formattedDate}</receiptDate>
				<entryDate>${formattedDate1}</entryDate>
				<cleanClaimDate>${formattedDate}</cleanClaimDate>
				<claimReviewRequired>false</claimReviewRequired>
				<encounter>false</encounter>
				<claimDeliveryType>Manual</claimDeliveryType>
				<payeeTypeField>Provider</payeeTypeField>
				<claimSource>Unknown</claimSource>
				<claimPayorType>2</claimPayorType>
				<renderingProviderCLIAId>P100001</renderingProviderCLIAId>
				<subscriberInformation>
					<subscriberIdentificationNumber>${memberandsubdata.memberarr[0].subid}</subscriberIdentificationNumber>
					<subscriberName>${memberandsubdata.subarray[0].subfullname}</subscriberName>
					<lastName>${memberandsubdata.subarray[0].sublastname}</lastName>
					<firstName>${memberandsubdata.subarray[0].subfirstname}</firstName>
					<streetAddress>${memberandsubdata.subarray[0].subaddress}</streetAddress>
					<cityName>${memberandsubdata.subarray[0].subcityname}</cityName>
					<stateCode>${memberandsubdata.subarray[0].substatecode}</stateCode>
					<genderCode>${memberandsubdata.subarray[0].subgender}</genderCode>
					<dateOfBirth>${memberandsubdata.subarray[0].subdob}</dateOfBirth>
					<benefitAssignment>Y</benefitAssignment>
				</subscriberInformation>
				<memberInformation>
					<memberIdentificationNumber>${memberandsubdata.memberarr[0].MemberID}</memberIdentificationNumber>
					<memberName>${memberandsubdata.memberarr[0].MemberFullname}</memberName>
					<lastName>${memberandsubdata.memberarr[0].MemberLastName}</lastName>
					<firstName>${memberandsubdata.memberarr[0].Memberfirstname}</firstName>
					<streetAddress>${memberandsubdata.memberarr[0].memberaddress}</streetAddress>
					<cityName>${memberandsubdata.memberarr[0].membercityname}</cityName>
					<stateCode>${memberandsubdata.memberarr[0].memberstatecode}</stateCode>
					<genderCode>${memberandsubdata.memberarr[0].membergender}</genderCode>
					<dateOfBirth>${memberandsubdata.memberarr[0].memberdob}</dateOfBirth>
				</memberInformation>
				<memberAuthorization>
					<releaseAuthorization>Y</releaseAuthorization>
				</memberAuthorization>
				<supplierInformationList>
					<supplierInformation>
						<supplierBillingName>${supplierdetails.supplierdetails[0].SupplierName}</supplierBillingName>
						<taxIdentificationNumber>${supplierdetails.supplierdetails[0].SupplierTaxID}</taxIdentificationNumber>
						<assignmentAcceptance>Y</assignmentAcceptance>
						<streetAddress>${supplierdetails.supplierdetails[0].SupplierAddress}</streetAddress>
						<cityName>${supplierdetails.supplierdetails[0].SupplierCity}</cityName>
						<stateCode>${supplierdetails.supplierdetails[0].SupplierState}</stateCode>
						<postalCode>${supplierdetails.supplierdetails[0].SupplierZip}</postalCode>
						<npi>${supplierdetails.supplierdetails[0].SupplierNpi}</npi>
					</supplierInformation>
				</supplierInformationList>
				<diagnosisCodes>
					<diagnosisCode>${diag}</diagnosisCode>
				</diagnosisCodes>
				<serviceLineItems>
					${tempstring}
				</serviceLineItems>
			</prof:professionalClaim>
		</soapenv:Body>
</soapenv:Envelope>`
 console.log(xml);
const { response } = await soapRequest({ url: url, headers: sampleHeaders, xml: xml });
//console.log("entering");
const { headers, body, statusCode } = response;
console.log(body);
claim_Id =await claimidextract(body);
console.log("claim_Id");
console.log(claim_Id);
return claim_Id;

 })();
 console.log("claimnumber");
 return claimnumber;
 }

 async function insclaimsoapUI(memberid,admitdiag,princdiag,typeofbill,arrayforclaimline,otherfields,supdata,supplierdetails,memberandsubdata) {
  var tempstring='';
  console.log(arrayforclaimline)

   for(k=0;k<arrayforclaimline.length;k++)
	 {
		   var claimline=
		   `<serviceLine>
		   <originalLineNumber>${i+1}</originalLineNumber>
		   <revenueCode>${arrayforclaimline[k].RevenueCode}</revenueCode>
		   <serviceCode>${arrayforclaimline[k].Servicecode}</serviceCode>
		   <serviceDate>2023-05-28</serviceDate>
		   <serviceUnitCount>1</serviceUnitCount>
		   <totalChargeAmount>100</totalChargeAmount>
		   <!--<institutionalClaimServiceModifier>-->
		   <!--<modifierCode>${arrayforclaimline[k].Modifier}</modifierCode>-->
		   <!--</institutionalClaimServiceModifier>-->
		   </serviceLine>`
						//console.log(claimline);
			tempstring = tempstring.concat("\n", claimline);
	 }
	 //console.log(tempstring);
	//}
	const url = 'http://100.112.45.153:8181/connector/services/v4/InstitutionalClaim';
	const sampleHeaders = {
		'Content-Type': 'text/xml;charset=UTF-8',
		'soapAction': 'http://healthedge.com/submit',
		'Authorization': 'Basic Y29ubmVjdG9yOkNvbm5lY3RvcjEyMw=='
	};
const claimnumber = (async () => {
		const xml = `<?xml version="1.0" encoding="UTF-8"?>
		<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
		xmlns:ins="http://www.healthedge.com/connector/schema/claim/institutional">
		<soapenv:Header/>
		<soapenv:Body>
		<ins:institutionalClaim>
		<receiptDate>${formattedDate}</receiptDate>
		<entryDate>${formattedDate1}</entryDate>
		<cleanClaimDate>${formattedDate}</cleanClaimDate>
		<claimReviewRequired>false</claimReviewRequired>
		<encounter>false</encounter>
		<claimDeliveryType>Manual</claimDeliveryType>
		<typeOfBillCode>${typeofbill}</typeOfBillCode>
		<totals>250.00</totals>
				 <payToInformation>
					<payToName>${memberandsubdata.memberarr[0].MemberFullname}</payToName>
					<address>${memberandsubdata.memberarr[0].memberaddress}r</address>
					<cityName>${memberandsubdata.memberarr[0].membercityname}</cityName>
					<stateCode>${memberandsubdata.memberarr[0].memberstatecode}</stateCode>
					<countryCode>
					   <countryCode>US</countryCode>
					</countryCode>
				 </payToInformation>
		<statementCoveredPeriod>
		<startDate>2023-03-01</startDate>
		<endDate>2023-05-31</endDate>
		</statementCoveredPeriod>
		<memberInformation>
		<memberIdentificationNumber>${memberandsubdata.memberarr[0].MemberID}</memberIdentificationNumber>
		<memberName>${memberandsubdata.memberarr[0].MemberFullname}</memberName>
		<lastName>${memberandsubdata.memberarr[0].MemberLastName}</lastName>
		<firstName>${memberandsubdata.memberarr[0].Memberfirstname}</firstName>
		<streetAddress>${memberandsubdata.memberarr[0].memberaddress}</streetAddress>
		<cityName>${memberandsubdata.memberarr[0].membercityname}</cityName>
		<stateCode>${memberandsubdata.memberarr[0].memberstatecode}</stateCode>
		<genderCode>${memberandsubdata.memberarr[0].membergender}</genderCode>
		<dateOfBirth>${memberandsubdata.memberarr[0].memberdob}</dateOfBirth>
		</memberInformation>
		<admissionInformation>
		<admissionDate>2023-01-01</admissionDate>
		<admissionTimeCount>10</admissionTimeCount>
		<admissionTypeCode>3</admissionTypeCode>
		<admissionSourceCode>1</admissionSourceCode>
		</admissionInformation>
		<supplierInformation>
		<taxIdentificationNumber>41-3897183</taxIdentificationNumber>
		<supplierName>${supplierdetails.supplierdetails[0].SupplierName}</supplierName>
		<assignmentAcceptance>Y</assignmentAcceptance>
		<address>${supplierdetails.supplierdetails[0].SupplierAddress}</address>
		<cityName>${supplierdetails.supplierdetails[0].SupplierCity}</cityName>
		<stateCode>${supplierdetails.supplierdetails[0].SupplierState}</stateCode>
		<npi>${supplierdetails.supplierdetails[0].SupplierNpi}</npi>
		</supplierInformation>
		<diagnosisList>
		<primaryDiagnosisCode>${princdiag}</primaryDiagnosisCode>
		<admitDiagnosisCode>${admitdiag}</admitDiagnosisCode>
		</diagnosisList>
		<insuranceInformation>
		<payerInformation>
		<benefitAssignmentIndicator>Y</benefitAssignmentIndicator>
		</payerInformation>
		<subscriberInformation>
		<subscriberName>${memberandsubdata.subarray[0].subfullname}</subscriberName>
		<relationshipToSubscriberCode>Self</relationshipToSubscriberCode>
		<identificationNumber>${memberandsubdata.memberarr[0].subid}</identificationNumber>
		<segmentedName>
		<firstName>${memberandsubdata.subarray[0].subfirstname}</firstName>
		<lastName>${memberandsubdata.subarray[0].sublastname}</lastName>
		</segmentedName>
		</subscriberInformation>
		</insuranceInformation>
		<otherPractitioner>
		<practitionerFirstName>Ronald</practitionerFirstName>
		<practitionerLastName>Noma</practitionerLastName>
		<practitionerId>P100001</practitionerId>
		</otherPractitioner>
		<institutionalServiceLineItem>
		${tempstring}
		</institutionalServiceLineItem>
		</ins:institutionalClaim>
		</soapenv:Body>`
//console.log(xml);
const { response } = await soapRequest({ url: url, headers: sampleHeaders, xml: xml });
const { headers, body, statusCode } = response;
console.log(body);
claim_Id =await claimidextract(body);
console.log("claim_Id");
console.log(claim_Id);
return claim_Id;
 })();

 return claimnumber;

 }
 async function claimidextract(soapResponse) 
 {
    debugger;
    try {
        var DomParser = require('dom-parser');
        var parser = new DomParser();
        const xmlDocument = parser.parseFromString(soapResponse, "text/xml");
        const claim = xmlDocument.getElementsByTagName("hccClaimNumber")[0];
        claim_Id = claim.textContent;
        //console.log("claimid"+claim_Id);
		//await takeclaimid(claim_Id)
    } catch (e) {
        console.log(e)
    }

    return {
		claim_Id
  }
}
async function inpatientsoapUI(startdate,enddate,dxcode,memberdata,supplierdetails,Authidrandm,refcat,servicecode) {
	//console.log(refcat)
	var tempstringforrefcat='';
	var tempstringsercode='';
	var finalservicetype='';
	const hasCommarefcat = refcat.includes(",");
	const hasCommaservicecode = servicecode.includes(",");
	// If the string does not contain a comma, simply return the string
		if (!hasCommarefcat) {
  		console.log("no comma")
		  var sertype=`
		  <serviceType>
		  <referralCategoryType>${refcat}</referralCategoryType>
		  </serviceType>
		  `
		  tempstringforrefcat=sertype;
		}
		else{
			const items = refcat.split(",");
			for (let i = 0; i < items.length; i++) {
  				const item = items[i].replace(/\s*,\s*/g, ",").trim();;
  				console.log(item);
				  var sertype=
				  `<serviceType>
				  <referralCategoryType>${item}</referralCategoryType>
				  </serviceType>`
				  tempstringforrefcat = tempstringforrefcat.concat("\n", sertype);
			}
		}
		
		if (!hasCommaservicecode) {
			console.log("no comma")
			let servicetype;
			servicetype=await getservicetype(servicecode);
			const srcode=servicetype.code;
			console.log(srcode);
			var sertype=
			`<serviceType>
					<serviceCode>${servicecode}</serviceCode>
					<serviceCodeType>${srcode}</serviceCodeType>
					</serviceType>
					`
					tempstringsercode=sertype;
		  }
		  else{
			  const items = servicecode.split(",");
			  let servicetype;
			  for (let i = 0; i < items.length; i++) {
					const item = items[i].replace(/\s*,\s*/g, ",").trim();;
					console.log(item);
					servicetype=await getservicetype(item);
					const srcode=servicetype.code;
					var sertype=
					`<serviceType>
					<serviceCode>${item}</serviceCode>
					<serviceCodeType>${srcode}</serviceCodeType>
					</serviceType>
					`
					tempstringsercode = tempstringsercode.concat("\n", sertype);
			  }
		  }
		  finalservicetype=tempstringforrefcat.concat("\n",tempstringsercode);
		  console.log(finalservicetype);
	  const url = 'http://100.112.45.153:8181/connector/services/v5/Authorization';
	  const sampleHeaders = {
		  'Content-Type': 'text/xml;charset=UTF-8',
		  'soapAction': 'http://healthedge.com/submit',
		  'Authorization': 'Basic Y29ubmVjdG9yOkNvbm5lY3RvcjEyMw=='
	  };
  		const aunumber = (async () => {
		  const xml = `
		  <!--Built By       : Manoj Kumar K-->
<!--Built on       : 09th, June 2023-->
<!--Modified on    : 14th, June 2023-->
<!--SOAP Request to create inpatient service autorization for multiple service types in HRP downstream applications-->
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:aut="http://www.healthedge.com/connector/schema/authorization">
<soapenv:Header/>
<soapenv:Body>
<aut:serviceAuthorization resourceURI="?" version="8.1">
<recordType>Authorization</recordType>
<authorizationId>${Authidrandm}</authorizationId>
<externalAuthorizationId>20230614-01</externalAuthorizationId>
<maintenanceInfo>
<transactionType>Create</transactionType>
<overrideAction>false</overrideAction>
</maintenanceInfo>
<requestDate>${formattedDate1}</requestDate>
<receivedDate>${formattedDate1}</receivedDate>
<requestedAdmitStatusCode>INPATIENT</requestedAdmitStatusCode>
<requestingProvider>
<providerType>SUPPLIER</providerType>
<providerNPIId>${supplierdetails.supplierdetails[0].SupplierNpi}</providerNPIId>
</requestingProvider>
<admissionInformation>
            <expectedAdmissionDateRangeStart>${formattedDate1}</expectedAdmissionDateRangeStart>
            <expectedAdmissionDateRangeEnd>${formattedDate1}</expectedAdmissionDateRangeEnd>
            <actualAdmissionDate>${formattedDate1}</actualAdmissionDate>
            <expectedDischargeDateRangeStart>${formattedDate1}</expectedDischargeDateRangeStart>
            <expectedDischargeDateRangeEnd>${formattedDate1}</expectedDischargeDateRangeEnd>
            <actualDischargeDate>${formattedDate1}</actualDischargeDate>
         </admissionInformation>
<servicesAction>DEFAULT</servicesAction>
<services>
<serviceSetIdentifier>20230614001</serviceSetIdentifier>
<startServiceDate>${formattedDate}</startServiceDate>
<endServiceDate>${formattedDate}</endServiceDate>
<requestedStartServiceDate>${formattedDate}</requestedStartServiceDate>
<requestedEndServiceDate>${formattedDate}</requestedEndServiceDate>
<receivedDate>${formattedDate1}</receivedDate>
<clinicalReceiptDate>${formattedDate1}</clinicalReceiptDate>
<serviceSetStatus>APPROVED</serviceSetStatus>
<!--Optional:-->
<allowUnlimitedDenials>true</allowUnlimitedDenials>
<!--Optional:-->
<approvedQuantity>100</approvedQuantity>
<approvedUnits>UNITS</approvedUnits>
<!-- <approvedAmount>85</approvedAmount>-->
<renderingProvider>
<providerType>SUPPLIER</providerType>
<providerNPIId>${supplierdetails.supplierdetails[0].SupplierNpi}</providerNPIId>
</renderingProvider>
<serviceTypes>
${finalservicetype}
</serviceTypes>
<diagnosis>
<diagnosisType>PRINCIPAL</diagnosisType>
<diagnosisCode>${dxcode}</diagnosisCode>
<diagnosisCodeType>ICD_10</diagnosisCodeType>
</diagnosis>
<hicApproval>
<authorizedBySystemUser>HCC_ADMIN</authorizedBySystemUser>
<authorizedDate>${formattedDate}</authorizedDate>
</hicApproval>
<authorizedStatusReasonCode>1</authorizedStatusReasonCode>
<authorizationTypeCode>3</authorizationTypeCode>
</services>
<diagnosis>
<diagnosisType>ADMITTING</diagnosisType>
<diagnosisCode>Y83.4</diagnosisCode>
<diagnosisCodeType>ICD_10</diagnosisCodeType>
</diagnosis>
<memberMatchInput>
<memberMatchInput>
<definitionName>MemberEnrollmentMatchDefinition</definitionName>
<member>
<firstName>${memberdata.memberarr[0].Memberfirstname}</firstName>
<lastName>${memberdata.memberarr[0].MemberLastName}</lastName>
<dateOfBirth>${memberdata.memberarr[0].memberdob}</dateOfBirth>
</member>
<asOfDate>1800-01-01</asOfDate>
</memberMatchInput>
</memberMatchInput>
</aut:serviceAuthorization>
</soapenv:Body>
</soapenv:Envelope>`
  //console.log(xml);
  const { response } = await soapRequest({ url: url, headers: sampleHeaders, xml: xml });
  const { headers, body, statusCode } = response;
  console.log(body);
  au_Id =await authidextract(body);
  //console.log("claim_Id");
 console.log(au_Id);
 return au_Id;
   })();
   return aunumber;
   }
 async function outpatientsoapUI(startdate,enddate,dxcode,memberdata,supplierdetails,Authidrandm,refcat,servicecode) {
	var tempstringforrefcat='';
	var tempstringsercode='';
	var finalservicetype='';
	const hasCommarefcat = refcat.includes(",");
	const hasCommaservicecode = servicecode.includes(",");
	// If the string does not contain a comma, simply return the string
		if (!hasCommarefcat) {
  		console.log("no comma")
		  var sertype=`
		  <serviceType>
		  <referralCategoryType>${refcat}</referralCategoryType>
		  </serviceType>
		  `
		  tempstringforrefcat=sertype;
		}
		else{
			const items = refcat.split(",");
			for (let i = 0; i < items.length; i++) {
  				const item = items[i].replace(/\s*,\s*/g, ",").trim();;
  				console.log(item);
				  var sertype=
				  `<serviceType>
				  <referralCategoryType>${item}</referralCategoryType>
				  </serviceType>`
				  tempstringforrefcat = tempstringforrefcat.concat("\n", sertype);
			}
		}
		
		if (!hasCommaservicecode) {
			console.log("no comma")
			let servicetype;
			servicetype=await getservicetype(servicecode);
			const srcode=servicetype.code;
			console.log(srcode);
			var sertype=
			`<serviceType>
					<serviceCode>${servicecode}</serviceCode>
					<serviceCodeType>${srcode}</serviceCodeType>
					</serviceType>
					`
					tempstringsercode=sertype;
		  }
		  else{
			  const items = servicecode.split(",");
			  let servicetype;
			  for (let i = 0; i < items.length; i++) {
					const item = items[i].replace(/\s*,\s*/g, ",").trim();;
					console.log(item);
					servicetype=await getservicetype(item);
					const srcode=servicetype.code;
					var sertype=
					`<serviceType>
					<serviceCode>${item}</serviceCode>
					<serviceCodeType>${srcode}</serviceCodeType>
					</serviceType>
					`
					tempstringsercode = tempstringsercode.concat("\n", sertype);
			  }
		  }
		  finalservicetype=tempstringforrefcat.concat("\n",tempstringsercode);
		  console.log(finalservicetype);
	  const url = 'http://100.112.45.153:8181/connector/services/v5/Authorization';
	  const sampleHeaders = {
		  'Content-Type': 'text/xml;charset=UTF-8',
		  'soapAction': 'http://healthedge.com/submit',
		  'Authorization': 'Basic Y29ubmVjdG9yOkNvbm5lY3RvcjEyMw=='
	  };
  		const aunumber = (async () => {
		  const xml = `
		  <!--Built By       : Manoj Kumar K-->
<!--Built on       : 04th, June 2023-->
<!--Modified on    : 14th, June 2023  and 20th, June 2023-->
<!--SOAP Request to create outpatient service autorization for multiple service types in HRP downstream applications-->
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:aut="http://www.healthedge.com/connector/schema/authorization">
<soapenv:Header/>
<soapenv:Body>
<aut:serviceAuthorization resourceURI="?" version="8.1">
<recordType>Authorization</recordType>
<authorizationId>${Authidrandm}</authorizationId>
<externalAuthorizationId>20230619-01</externalAuthorizationId>
<maintenanceInfo>
<transactionType>Create</transactionType>
<overrideAction>false</overrideAction>
</maintenanceInfo>
<requestDate>${formattedDate1}</requestDate>
<receivedDate>${formattedDate1}</receivedDate>
<requestedAdmitStatusCode>OUTPATIENT</requestedAdmitStatusCode>
<requestingProvider>
<providerType>SUPPLIER</providerType>
<providerNPIId>${supplierdetails.supplierdetails[0].SupplierNpi}</providerNPIId>
</requestingProvider>
<servicesAction>DEFAULT</servicesAction>
<services>
<serviceSetIdentifier>20230619001</serviceSetIdentifier>
<startServiceDate>${formattedDate}</startServiceDate>
<endServiceDate>${formattedDate}</endServiceDate>
<requestedStartServiceDate>${formattedDate}</requestedStartServiceDate>
<requestedEndServiceDate>${formattedDate}</requestedEndServiceDate>
<receivedDate>${formattedDate1}</receivedDate>
<clinicalReceiptDate>${formattedDate1}</clinicalReceiptDate>
<serviceSetStatus>APPROVED</serviceSetStatus>
<!--Optional:-->
<allowUnlimitedDenials>true</allowUnlimitedDenials>
<!--Optional:-->
<approvedQuantity>100</approvedQuantity>
<approvedUnits>UNITS</approvedUnits>
<!-- <approvedAmount>85</approvedAmount>-->
<renderingProvider>
<providerType>SUPPLIER</providerType>
<providerNPIId>${supplierdetails.supplierdetails[0].SupplierNpi}</providerNPIId>
</renderingProvider>
<serviceTypes>
${finalservicetype}
</serviceTypes>
<diagnosis>
<diagnosisCode>${dxcode}</diagnosisCode>
<diagnosisCodeType>ICD_10</diagnosisCodeType>
</diagnosis>
<hicApproval>
<authorizedBySystemUser>manoj</authorizedBySystemUser>
<authorizedDate>${formattedDate}</authorizedDate>
</hicApproval>
<authorizedStatusReasonCode>1</authorizedStatusReasonCode>
<authorizationTypeCode>3</authorizationTypeCode>
</services>
<placeOfService>11</placeOfService>
<memberMatchInput>
<memberMatchInput>
<definitionName>MemberEnrollmentMatchDefinition</definitionName>
<member>
<firstName>${memberdata.memberarr[0].Memberfirstname}</firstName>
<lastName>${memberdata.memberarr[0].MemberLastName}</lastName>
<dateOfBirth>${memberdata.memberarr[0].memberdob}</dateOfBirth>
</member>
<asOfDate>1800-01-01</asOfDate>
</memberMatchInput>
</memberMatchInput>
</aut:serviceAuthorization>
</soapenv:Body>
</soapenv:Envelope>
`
 // console.log(xml);
  const { response } = await soapRequest({ url: url, headers: sampleHeaders, xml: xml });
  const { headers, body, statusCode } = response;
  console.log(body);
  au_Id =await authidextract(body);
  //console.log("claim_Id");
 console.log(au_Id);
 return au_Id;
   })();
  
   return aunumber;
  
   }

   async function authidextract(soapResponse) 
   {
	  debugger;
	  try {
		  var DomParser = require('dom-parser');
		  var parser = new DomParser();
		  const xmlDocument = parser.parseFromString(soapResponse, "text/xml");
		  const claim = xmlDocument.getElementsByTagName("authorizationId")[0];
		  a_Id = claim.textContent;
		  //console.log("claimid"+claim_Id);
		  //await takeclaimid(claim_Id)
	  } catch (e) {
		  console.log(e)
	  }
  
	  return {
		a_Id
	}
  }

  async function getservicetype(servicecode) 
{
	try{
		connection = await oracledb.getConnection({
		  user: 'citi_abagchi',
		  password: 'U4ggPVAg9PNuJ',
		  connectString: '100.112.45.151:1521/CITPDWTT'
		});
		const Account = await connection.execute(`SELECT DISTINCT 
		CASE 
		WHEN SER.SERVICE_TYPE_NAME = 'UB Revenue Code' THEN 'UB_REVENUE'
		WHEN SER.SERVICE_TYPE_NAME = 'CPT-4 code' THEN 'CPT-4'
		WHEN SER.SERVICE_TYPE_NAME = 'HCPCS code' THEN 'HCPCS'
		ELSE SER.SERVICE_TYPE_NAME
		END AS SERVICE_TYPE_NAME
		, SER.SERVICE_CODE
		 FROM PAYOR_DW.SERVICE SER WHERE SER.SERVICE_CODE = '${servicecode}'
		`);
		var code=Account.rows[0][0];
		
	  console.log(code);
		return {
			code
		 }
		} catch (err) {
		  console.error(err);
		} finally {
		  if (connection) {
			try {
			  await connection.close();
			} catch (err) {
			  console.error(err);
			}
		  }
		}
}
async function getdbvaluesupplier(supid) 
{
var arraysupp=[];
var supplocation;
var addrline;
var city;
var citycode;
var zipcode;
var npi;
var supnpi;
var supname;

   try{
    connection = await oracledb.getConnection({
        user: 'citi_abagchi',
        password: 'U4ggPVAg9PNuJ',
        connectString: '100.112.45.151:1521/CITPDWTT'
    });
    try{
    acckey= await connection.execute("SELECT SL.SUPPLIER_LOCATION_NAME,PA.ADDRESS_LINE,PA.CITY_NAME,PA.STATE_CODE,PA.ZIP_CODE,PA.COUNTRY_NAME,SL.SUPPLIER_LOCATION_NPI,SHF.SUPPLIER_NPI,SHF.SUPPLIER_NAME FROM PAYOR_DW.ALL_SUPPLIER_HISTORY_FACT SHF INNER JOIN PAYOR_DW.SUPPLIER_LOCATION_HIST_FACT SL ON SL.SUPPLIER_KEY = SHF.SUPPLIER_KEY INNER JOIN PAYOR_DW.POSTAL_ADDRESS PA ON PA.POSTAL_ADDRESS_KEY = SL.CORRESPONDENCE_ADDRESS_KEY WHERE SHF.SUPPLIER_HCC_ID='"+supid+"'");
	
	supplocation=acckey.rows[0][0];
	addrline=acckey.rows[0][1];
	city=acckey.rows[0][2];
	citycode=acckey.rows[0][3];
	zipcode=acckey.rows[0][4];
	npi=acckey.rows[0][6];
	supnpi=acckey.rows[0][7];
	supname=acckey.rows[0][8];
	}
	catch(e)
	{
	supplocation='';
	addrline=''
	city='';
	citycode='';
	zipcode='';
	npi='';
	supnpi='';
	supname='';
	}
	arraysupp.push({"sublocation":supplocation,"add":addrline,"city":city,"citycode":citycode,"zipcode":zipcode,"npi":npi,"supnpi":supnpi,"supname":supname})
	console.log(arraysupp);
    return {
		arraysupp
    }
   } catch (err) {
      console.error(err);
    } finally {
      if (connection) {
        try {
          await connection.close();
        } catch (err) {
          console.error(err);
        }
      }
    }
}
async function getsupplierdetails(supid) 
{
		var supplierdetails=[];
		var SupplierHCC='';
		var SupplierName=''
		var SupplierAddress='';
		var SupplierCity='';
		var SupplierState='';
		var SupplierZip='';
		var SupplierTaxID='';
		var SupplierNpi='';

   try{
    connection = await oracledb.getConnection({
        user: 'citi_abagchi',
        password: 'U4ggPVAg9PNuJ',
        connectString: '100.112.45.151:1521/CITPDWTT'
    });
    
    acckey= await connection.execute("SELECT SHF.SUPPLIER_HCC_ID,SHF.SUPPLIER_NAME,PA.ADDRESS_LINE,PA.CITY_NAME,PA.STATE_CODE,PA.ZIP_CODE,PA.COUNTRY_NAME,THF.TAX_ID,SHF.SUPPLIER_NPI FROM PAYOR_DW.ALL_SUPPLIER_HISTORY_FACT SHF INNER JOIN PAYOR_DW.POSTAL_ADDRESS PA ON PA.POSTAL_ADDRESS_KEY = SHF.SUPPLIER_CORR_ADDRESS_KEY INNER JOIN PAYOR_DW.TAX_ENTITY_HISTORY_FACT THF ON THF.TAX_ENTITY_KEY = SHF.TAX_ENTITY_KEY where SHF.SUPPLIER_HCC_ID='"+supid+"'");
	try{
	SupplierHCC=acckey.rows[0][0];
	SupplierName=acckey.rows[0][1];
	SupplierAddress=acckey.rows[0][2];
	SupplierCity=acckey.rows[0][3];
	SupplierState=acckey.rows[0][4];
	SupplierZip=acckey.rows[0][5];
	SupplierTaxID=acckey.rows[0][7];
	SupplierNpi=acckey.rows[0][8];
	console.log(SupplierNpi);
	}
	catch(e)
	{
		SupplierHCC='';
		SupplierName=''
		SupplierAddress='';
		SupplierCity='';
		SupplierState='';
		SupplierZip='';
		SupplierTaxID='';
		SupplierNpi='';
	}
	supplierdetails.push({"SupplierHCC":SupplierHCC,"SupplierName":SupplierName,"SupplierAddress":SupplierAddress,"SupplierCity":SupplierCity,"SupplierState":SupplierState,"SupplierZip":SupplierZip,"SupplierTaxID":SupplierTaxID,"SupplierNpi":SupplierNpi})
	//console.log(supplierdetails);
    return {
		supplierdetails
    }
   } catch (err) {
      console.error(err);
    } finally {
      if (connection) {
        try {
          await connection.close();
        } catch (err) {
          console.error(err);
        }
      }
    }
}
async function getdbvaluesmembsub(memberid) 
{
const memberarr=[];
const subarray=[];
let subid='';
var memid;
var acckey;
var acckey1;
var memfullname;
var memberlastname;
var memberfirstname;
var memberaddress;
var membercityname;
var memberstatecode;
var membergender;
var subfullname;
var sublastname;
var subfirstname;
var memberdob;
var dobslice1
var donbslice2
let  formattedDatedob;
let formattedDateDOB;

console.log(memberid);
   try{
    connection = await oracledb.getConnection({
        user: 'citi_abagchi',
        password: 'U4ggPVAg9PNuJ',
        connectString: '100.112.45.151:1521/CITPDWTT'
    });
    try{
    acckey= await connection.execute(`SELECT 
	DISTINCT MHF.SUBSCRIPTION_HCC_ID,
	MHF.MEMBER_HCC_ID,
	MHF.MEMBER_FULL_NAME,
	MHF.MEMBER_LAST_NAME,
	MHF.MEMBER_FIRST_NAME,
	PA.ADDRESS_LINE,
	PA.CITY_NAME,
	pa.state_code,
	MHF.MEMBER_GENDER_CODE,
	DD.DATE_VALUE AS BirthDate,
	MHF.MEMBER_HISTORY_FACT_KEY
	FROM
	
				   PAYOR_DW.ALL_MEMBER_VERSION_HIST_FACT MHF
				   INNER JOIN PAYOR_DW.DATE_DIMENSION memVerEffDt ON mhf.VERSION_EFF_DATE_KEY = memVerEffDt.DATE_KEY 
				   INNER JOIN PAYOR_DW.DATE_DIMENSION memVerExpDt ON mhf.VERSION_EXP_DATE_KEY = memVerExpDt.DATE_KEY INNER JOIN PAYOR_DW.ALL_ACCOUNT_HISTORY_FACT AHF ON MHF.ACCOUNT_KEY = AHF.ACCOUNT_KEY
				   INNER JOIN PAYOR_DW.POSTAL_ADDRESS PA ON PA.postal_address_key = mhf.MEMBER_MAILING_ADDRESS_KEY
				   INNER JOIN PAYOR_DW.DATE_DIMENSION DD ON DD.DATE_KEY = MHF.MEMBER_BIRTH_DATE_KEY
				   LEFT JOIN PAYOR_DW.MEMBER_HIST_FACT_TO_BNFT_PLAN PLAN_LINK ON PLAN_LINK.MEMBER_HISTORY_FACT_KEY = MHF.MEMBER_HISTORY_FACT_KEY
				   AND PLAN_LINK.SORT_ORDER = 1
				   LEFT JOIN PAYOR_DW.BENEFIT_PLAN_HISTORY_FACT BPLAN ON BPLAN.BENEFIT_PLAN_KEY = PLAN_LINK.BENEFIT_PLAN_KEY
				   AND MHF.VERSION_EFF_DATE_KEY >= BPLAN.VERSION_EFF_DATE_KEY
				   AND MHF.VERSION_EXP_DATE_KEY <= BPLAN.VERSION_EXP_DATE_KEY
	WHERE
	SYSDATE >= memVerEffDt.DATE_VALUE AND SYSDATE < memVerExpDt.DATE_VALUE
	AND
	MHF.MEMBER_HCC_ID = '${memberid}' 
	AND
	MHF.MEMBER_STATUS = 'a'
	ORDER BY MHF.MEMBER_HISTORY_FACT_KEY DESC`);
	
	subid=acckey.rows[0][0];
	memid=acckey.rows[0][1];
	memfullname=acckey.rows[0][2];
	memberlastname=acckey.rows[0][3];
	memberfirstname=acckey.rows[0][4];
	memberaddress=acckey.rows[0][5];
	membercityname=acckey.rows[0][6];
	memberstatecode=acckey.rows[0][7];
	membergender=acckey.rows[0][8];
	memberdob=acckey.rows[0][9];
	console.log(memberdob);
	dobslice1=memberdob.toString();
	const date1 = new Date(dobslice1);
	const year1 = date1.getFullYear();
	const month1 = date1.getMonth() + 1;
	const day1 = date1.getDate();
	const month2Digit1 = month1 < 10 ? "0" + month1 : month1;
	const day2Digit1 = day1 < 10 ? "0" + day1 : day1;
	// Format the date into the desired format.
	formattedDateDOB = `${year1}-${month2Digit1}-${day2Digit1}`;
	console.log(formattedDateDOB);
	
	console.log("memberarray"+memberarr);

	}
	catch(e)
	{
	subid='';
	memid='';
	memfullname='';
	memberlastname='';
	memberfirstname='';
	memberaddress='';
	membercityname='';
	memberstatecode='';
	membergender='';
	memberdob='';
	}
	memberarr.push({"subid":subid,"MemberID":memid,"MemberFullname":memfullname,"MemberLastName":memberlastname,"Memberfirstname":memberfirstname,"memberaddress":memberaddress,"membercityname":membercityname,"memberstatecode":memberstatecode,"membergender":membergender,"memberdob":formattedDateDOB});
// Get the year, month, and day from the Date object.

	// subfullname=acckey.rows[0][9];
	// sublastname=acckey.rows[0][10];
	// subfirstname=acckey.rows[0][11];
	
	try{
	acckey1= await connection.execute(`SELECT 
		DISTINCT MHF.SUBSCRIPTION_HCC_ID, 
		MHF.MEMBER_HCC_ID, 
		MHF.MEMBER_FULL_NAME, 
		MHF.MEMBER_LAST_NAME, 
		MHF.MEMBER_FIRST_NAME, 
		PA.ADDRESS_LINE, 
		PA.CITY_NAME, 
		pa.state_code, 
		MHF.MEMBER_GENDER_CODE, 
		DD.DATE_VALUE AS BirthDate 
	  FROM 
		PAYOR_DW.ALL_MEMBER_VERSION_HIST_FACT MHF 
		INNER JOIN PAYOR_DW.ALL_ACCOUNT_HISTORY_FACT AHF ON MHF.ACCOUNT_KEY = AHF.ACCOUNT_KEY 
		INNER JOIN PAYOR_DW.POSTAL_ADDRESS PA ON PA.postal_address_key = mhf.MEMBER_MAILING_ADDRESS_KEY 
		INNER JOIN PAYOR_DW.DATE_DIMENSION DD ON DD.DATE_KEY = MHF.MEMBER_BIRTH_DATE_KEY 
		LEFT JOIN PAYOR_DW.MEMBER_HIST_FACT_TO_BNFT_PLAN PLAN_LINK ON PLAN_LINK.MEMBER_HISTORY_FACT_KEY = MHF.MEMBER_HISTORY_FACT_KEY 
		AND PLAN_LINK.SORT_ORDER = 1 
		LEFT JOIN PAYOR_DW.BENEFIT_PLAN_HISTORY_FACT BPLAN ON BPLAN.BENEFIT_PLAN_KEY = PLAN_LINK.BENEFIT_PLAN_KEY 
		AND MHF.VERSION_EFF_DATE_KEY >= BPLAN.VERSION_EFF_DATE_KEY 
		AND MHF.VERSION_EXP_DATE_KEY <= BPLAN.VERSION_EXP_DATE_KEY 
	  WHERE 
	   MHF.SUBSCRIPTION_HCC_ID = '${subid}'`
	);
	subfullname=acckey1.rows[0][2];
	sublastname=acckey1.rows[0][3];
	subfirstname=acckey1.rows[0][4];
	subaddress=acckey1.rows[0][5];
	subcityname=acckey1.rows[0][6];
	substatecode=acckey1.rows[0][7];
	subgender=acckey1.rows[0][8];
	subdob=acckey1.rows[0][9];
	donbslice2=subdob.toString();
	const date = new Date(donbslice2);
	// Get the year, month, and day from the Date object.
	const year = date.getFullYear();
	const month = date.getMonth() + 1;
	const day = date.getDate();
	const month2Digit2 = month < 10 ? "0" + month : month;
	const day2Digit2 = day < 10 ? "0" + day : day;	
	// Format the date into the desired format.
	formattedDatedob = `${year}-${month2Digit2}-${day2Digit2}`;
	console.log("member data"+subarray);
	}
	catch(e)
	{
	subfullname='';
	sublastname='';
	subfirstname='';
	subaddress='';
	subcityname='';
	substatecode='';
	subgender='';
	subdob='';
	}
	// subfullname=acckey.rows[0][9];
	// sublastname=acckey.rows[0][10];
	// subfirstname=acckey.rows[0][11];
	subarray.push({"subfullname":subfullname,"sublastname":sublastname,"subfirstname":subfirstname,"subaddress":subaddress,"subcityname":subcityname,"substatecode":substatecode,"subgender":subgender,"subdob":formattedDatedob});

    return {
		memberarr,subarray
    }
   } catch (err) {
      console.error(err);
    } finally {
      if (connection) {
        try {
          await connection.close();
        } catch (err) {
          console.error(err);
        }
      }
    }
}

function checkAllNull(jsonData) {
	for (let i = 0; i < jsonData.supplierdetails.length; i++) {
		for (let key in jsonData.supplierdetails[i]) {
		  if (jsonData.supplierdetails[i][key] == '') {
			  return true;
			}
			else{
			return false;
			}
		  }
		}

	  }
	  function checkAllNullMember(jsonData) {
		for (let i = 0; i < jsonData.memberarr.length; i++) {
			for (let key in jsonData.memberarr[i]) {
			  if (jsonData.memberarr[i][key] == '') {
				  return true;
				}
				else{
				return false;
				}
			  }
			}
	
		  }
	  
	

 module.exports = {
    proclaimsoapUI,getdbvaluesupplier,getdbvaluesmembsub,insclaimsoapUI,getsupplierdetails,checkAllNull,checkAllNullMember,outpatientsoapUI,inpatientsoapUI,getservicetype
  }