//import { familysoapUI } from './soapcall.js';
//const soapcall = require('./conn');
const oracleconnection = require('./conn');
const soapcall = require('./soapcall');

const oracledb = require('oracledb');
var acc1;
// Get Account Name
async function getAccountNames() {
  try{
  connection = await oracledb.getConnection({
    user: 'citi_abagchi',
    password: 'U4ggPVAg9PNuJ',
    connectString: '100.112.45.151:1521/CITPDWTT'
  });
  const Account = await connection.execute(`SELECT 
  AHF."ACCOUNT_NAME"
  FROM PAYOR_DW.ALL_ACCOUNT_HISTORY_FACT AHF
       INNER JOIN PAYOR_DW.DATE_DIMENSION EFFDT ON EFFDT.DATE_KEY = AHF.VERSION_EFF_DATE_KEY
       INNER JOIN PAYOR_DW.DATE_DIMENSION EXPDT ON EXPDT.DATE_KEY = AHF.VERSION_EXP_DATE_KEY
       LEFT OUTER JOIN PAYOR_DW.TAX_ENTITY TEHF ON AHF.TAX_ENTITY_KEY = TEHF.TAX_ENTITY_KEY
       INNER JOIN PAYOR_DW.POSTAL_ADDRESS PA ON PA.POSTAL_ADDRESS_KEY = AHF.ACCOUNT_CORR_ADDRESS_KEY 
       INNER JOIN PAYOR_DW.STATE_CODE SC ON SC.STATE_CODE = PA.STATE_CODE
  WHERE 
  EFFDT.DATE_VALUE   <= SYSDATE
  AND EXPDT.DATE_VALUE > SYSDATE
  `);
  var Acc=Account.rows
  

  return {
    Acc
   }
  } catch (err) {
    console.error(err);
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }

}
async function getmemberid() {
  try{
  connection = await oracledb.getConnection({
    user: 'citi_abagchi',
    password: 'U4ggPVAg9PNuJ',
    connectString: '100.112.45.151:1521/CITPDWTT'
  });
  const Account = await connection.execute(`SELECT DISTINCT
  MHF.MEMBER_HCC_ID AS MEMBER_ID
  FROM 
  PAYOR_DW.all_member_version_hist_fact mhf, 
  PAYOR_DW.DATE_DIMENSION effDt, 
  PAYOR_DW.DATE_DIMENSION expDt
  WHERE
  effDt.DATE_KEY = mhf.VERSION_EFF_DATE_KEY and
  expDt.DATE_KEY = mhf.VERSION_EXP_DATE_KEY and
  effDt.DATE_VALUE <= SYSDATE and
  expDt.DATE_VALUE > SYSDATE and
  MHF.MEMBER_HCC_ID IS  NOT NULL
  ORDER BY mhf.member_hcc_id
  `);
  var Acc=Account.rows

  return {
    Acc
   }
  } catch (err) {
    console.error(err);
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }

}

// Post Account Name and Get Benefit Plans list 
async function getBenefitplans(data) {
  //SQL connections open 
  try{

  connection = await oracledb.getConnection({
    user: 'citi_abagchi',
    password: 'U4ggPVAg9PNuJ',
    connectString: '100.112.45.151:1521/CITPDWTT'
  });
  
  acckey= await connection.execute("SELECT account_key FROM PAYOR_DW.ALL_ACCOUNT_HISTORY_FACT where account_name='"+data+"'");
  acc1=acckey.rows[0][0];
  const benefit_pan = await connection.execute("SELECT BENEFIT_PLAN_DESC FROM payor_dw.benefit_plan bf JOIN payor_dw.account_plan_select_fact ap ON bf.benefit_plan_key=ap.benefit_plan_key WHERE ap.account_key='"+acc1+"'");  
   var bene=benefit_pan.rows

  const statename=await connection.execute("SELECT SC.STATE_NAME FROM PAYOR_DW.ALL_ACCOUNT_HISTORY_FACT AHF INNER JOIN PAYOR_DW.DATE_DIMENSION EFFDT ON EFFDT.DATE_KEY = AHF.VERSION_EFF_DATE_KEY INNER JOIN PAYOR_DW.DATE_DIMENSION EXPDT ON EXPDT.DATE_KEY = AHF.VERSION_EXP_DATE_KEY LEFT OUTER JOIN PAYOR_DW.TAX_ENTITY TEHF ON AHF.TAX_ENTITY_KEY = TEHF.TAX_ENTITY_KEY INNER JOIN PAYOR_DW.POSTAL_ADDRESS PA ON PA.POSTAL_ADDRESS_KEY = AHF.ACCOUNT_CORR_ADDRESS_KEY INNER JOIN PAYOR_DW.STATE_CODE SC ON SC.STATE_CODE = PA.STATE_CODE WHERE EFFDT.DATE_VALUE   <= SYSDATE AND EXPDT.DATE_VALUE > SYSDATE AND AHF.account_key = '"+acc1+"'");
  var state=statename.rows;

  return {
    bene,
    state
   }
  } catch (err) {
    console.error(err);
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }
  
  }

  async function getdatafromSoap(SOAPData,subtype) {
   var member_id;
   var statecode='';
   var zipode='';
   var accHCCID='';
   var beneHCCID='';
   var SOAPDatanode = [];
   var firstname='';
   var lastName='';
   var address='';
   var state='';
   var gender=''
   var dob;
   var AccHCCplan;
   var beneHCCplan;
   var subname;
   var memberidref
   var sub_id;
   var subscriptionId;

//console.log(subtype);
if(subtype=="Subscriber Only")
{
    for (var i=0;i<SOAPData.length;i++)
    {
      const SSN1 = Math.floor(Math.random()*800) + 100;
      const SSN2 = Math.floor(Math.random()*80) + 10;
      const SSN3 = Math.floor(Math.random()*8000) + 1000;
      const SSN=SSN1+"-"+SSN2+"-"+SSN3;
      
      statecode=await soapcall.getdbvalue('statecode',acc1)
      console.log(SSN);
      zipode = await soapcall.getdbvalue("zipcode",acc1)
      AccHCCplan = await soapcall.getdbvalue("AccHcc",acc1)
      //beneHCCplan= await soapcall.getdbvalue("beneHcc",acc1);
      //console.log(statecode.code+" "+zipode.code+" "+AccHCCplan.code);
      statecode=statecode.code;
      subname=SOAPData[i].subscriber.replace(/[0-9]/g, '');
      //console.log(subname);
    
      //if(subname=='Subscriber'){
        subscriptionId = Math.floor(Math.random()*90000000) + 10000000;
        sub_id="A"+subscriptionId
      //}
      zipode=zipode.code;
      accHCCID=AccHCCplan.code;
      beneHCCID=SOAPData[i].Benefit_Plan;
      //console.log("benefit:"+beneHCCID);
      firstname=SOAPData[i].Firstname;
      lastName=SOAPData[i].lastname;
      address=SOAPData[i].Address;
      state=SOAPData[i].State;
      gender=SOAPData[i].Gender;
      dob =SOAPData[i].Dateofbirth;
      console.log(firstname+','+lastName+','+address+','+state+','+gender+','+dob);

        memberidref=sub_id+"00"
        member_id=await soapcall.SOAPUIConfig(firstname,lastName,address,state,gender,dob,accHCCID,beneHCCID,zipode,statecode,SSN,"Self",sub_id,memberidref);
      
      SOAPDatanode.push({
        "sub_node":SOAPData[i].subscriber,
         "Account_node":SOAPData[i].Account,
         "Benefit_Plan_node":SOAPData[i].Benefit_Plan,
         "Firstname_node":SOAPData[i].Firstname,
         "lastname_node":SOAPData[i].lastname,
         "Dateofbirth_node":SOAPData[i].Dateofbirth,
         "Gender_node":SOAPData[i].Gender,
         "Address_node":SOAPData[i].Address,
         "State_node":SOAPData[i].State,
         "MemberID_node":memberidref,
         });
      }
    }

    if(subtype=="Subscriber + Family"){
      const arrayforitrate = [];
      const SSN1 = Math.floor(Math.random()*800) + 100;
      const SSN2 = Math.floor(Math.random()*80) + 10;
      const SSN3 = Math.floor(Math.random()*8000) + 1000;
      const SSN=SSN1+"-"+SSN2+"-"+SSN3;
       
    for (var i=0;i<SOAPData.length;i++)
    {
      
      statecode=await soapcall.getdbvalue('statecode',acc1)
      //console.log(SSN);
      zipode = await soapcall.getdbvalue("zipcode",acc1)
      AccHCCplan = await soapcall.getdbvalue("AccHcc",acc1)
      //beneHCCplan= await soapcall.getdbvalue("beneHcc",acc1);
      //console.log(statecode.code+" "+zipode.code+" "+AccHCCplan.code);
      statecode=statecode.code;
      subname=SOAPData[i].subscriber.replace(/[0-9]/g, '');
      console.log(subname);
      if(subname=='Subscriber'){
        subscriptionId = Math.floor(Math.random()*90000000) + 10000000;
        sub_id="A"+subscriptionId
      }
      zipode=zipode.code;
      accHCCID=AccHCCplan.code;
      beneHCCID=SOAPData[i].Benefit_Plan;
      //console.log("benefit:"+beneHCCID);
      firstname=SOAPData[i].Firstname;
      lastName=SOAPData[i].lastname;
      address=SOAPData[i].Address;
      state=SOAPData[i].State;
      gender=SOAPData[i].Gender;
      dob=SOAPData[i].Dateofbirth;
      console.log(firstname+','+lastName+','+address+','+state+','+gender+','+dob);
      //memberidref=sub_id+"0"+i;
      if (subname=="Subscriber"){
        memberidref=sub_id+"00";
      }
      if(subname=="Spouse"){
        memberidref=sub_id+"01";
      }
      if(subname=="Child"){
        memberidref=sub_id+"02";
      }
      console.log(subname);
      console.log(memberidref);
      SOAPDatanode.push({
        "sub_node":SOAPData[i].subscriber,
         "Account_node":SOAPData[i].Account,
         "Benefit_Plan_node":SOAPData[i].Benefit_Plan,
         "Firstname_node":SOAPData[i].Firstname,
         "lastname_node":SOAPData[i].lastname,
         "Dateofbirth_node":SOAPData[i].Dateofbirth,
         "Gender_node":SOAPData[i].Gender,
         "Address_node":SOAPData[i].Address,
         "State_node":SOAPData[i].State,
         "MemberID_node":memberidref,
         });
        // console.log(SOAPDatanode);
         //let firstnameconcat="firstname"+i;
         arrayforitrate.push({"firstname":firstname,"lastName":lastName,"dob":dob,"gender":gender,"address":address,"memberid":memberidref});
         
         //console.log(arrayforitrate);
         

         //console.log(subname);
         if (subname != "Child") { continue; }
        // console.log("comin");
         //console.log(SOAPDatanode);
         member_id=await soapcall.familysoapUI(arrayforitrate,accHCCID,beneHCCID,zipode,statecode,SSN,sub_id);
      }
    }
    if(subtype=="Subscriber + children"){
      const arrayforitrate = [];
      const SSN1 = Math.floor(Math.random()*800) + 100;
      const SSN2 = Math.floor(Math.random()*80) + 10;
      const SSN3 = Math.floor(Math.random()*8000) + 1000;
      const SSN=SSN1+"-"+SSN2+"-"+SSN3;
     
    for (var i=0;i<SOAPData.length;i++)
    {
      
      statecode=await soapcall.getdbvalue('statecode',acc1)
      //console.log(SSN);
      zipode = await soapcall.getdbvalue("zipcode",acc1)
      AccHCCplan = await soapcall.getdbvalue("AccHcc",acc1)
      //beneHCCplan= await soapcall.getdbvalue("beneHcc",acc1);
      //console.log(statecode.code+" "+zipode.code+" "+AccHCCplan.code);
      statecode=statecode.code;
      subname=SOAPData[i].subscriber.replace(/[0-9]/g, '');
      //console.log(subname);
    
      if(subname=='Subscriber'){
        subscriptionId = Math.floor(Math.random()*90000000) + 10000000;
        sub_id="A"+subscriptionId
      }
      zipode=zipode.code;
      accHCCID=AccHCCplan.code;
      beneHCCID=SOAPData[i].Benefit_Plan;
      //console.log("benefit:"+beneHCCID);
      firstname=SOAPData[i].Firstname;
      lastName=SOAPData[i].lastname;
      address=SOAPData[i].Address;
      state=SOAPData[i].State;
      gender=SOAPData[i].Gender;
      dob=SOAPData[i].Dateofbirth;
      console.log(firstname+','+lastName+','+address+','+state+','+gender+','+dob);
      if (subname=="Subscriber"){memberidref=sub_id+"00";}
     // if(subname=="Spouse"){memberidref=sub_id+"01"}
      if(subname=="Child"){memberidref=sub_id+"01"}
      console.log(memberidref);
      SOAPDatanode.push({
        "sub_node":SOAPData[i].subscriber,
         "Account_node":SOAPData[i].Account,
         "Benefit_Plan_node":SOAPData[i].Benefit_Plan,
         "Firstname_node":SOAPData[i].Firstname,
         "lastname_node":SOAPData[i].lastname,
         "Dateofbirth_node":SOAPData[i].Dateofbirth,
         "Gender_node":SOAPData[i].Gender,
         "Address_node":SOAPData[i].Address,
         "State_node":SOAPData[i].State,
         "MemberID_node":memberidref,
         });
         console.log(SOAPDatanode);
         //let firstnameconcat="firstname"+i;
         arrayforitrate.push({"firstname":firstname,"lastName":lastName,"dob":dob,"gender":gender,"address":address,"memberid":memberidref});
         
         console.log(arrayforitrate);
         

         console.log(subname);
         if (subname != "Child") { continue; }
         console.log("comin");
         console.log(SOAPDatanode);
         member_id=await soapcall.childsoapUI(arrayforitrate,accHCCID,beneHCCID,zipode,statecode,SSN,sub_id);
      }
    }
    if(subtype=="Subscriber + Spouse"){
      const arrayforitrate = [];
      const SSN1 = Math.floor(Math.random()*800) + 100;
      const SSN2 = Math.floor(Math.random()*80) + 10;
      const SSN3 = Math.floor(Math.random()*8000) + 1000;
      const SSN=SSN1+"-"+SSN2+"-"+SSN3;
      
    for (var i=0;i<SOAPData.length;i++)
    {
      statecode=await soapcall.getdbvalue('statecode',acc1)
      //console.log(SSN);
      zipode = await soapcall.getdbvalue("zipcode",acc1)
      AccHCCplan = await soapcall.getdbvalue("AccHcc",acc1)
      //beneHCCplan= await soapcall.getdbvalue("beneHcc",acc1);
      //console.log(statecode.code+" "+zipode.code+" "+AccHCCplan.code);
      statecode=statecode.code;
      subname=SOAPData[i].subscriber.replace(/[0-9]/g, '');
      //console.log(subname);
    
      if(subname=='Subscriber'){
        subscriptionId = Math.floor(Math.random()*90000000) + 10000000;
        sub_id="A"+subscriptionId
      }
      zipode=zipode.code;
      accHCCID=AccHCCplan.code;
      beneHCCID=SOAPData[i].Benefit_Plan;
      //console.log("benefit:"+beneHCCID);
      firstname=SOAPData[i].Firstname;
      lastName=SOAPData[i].lastname;
      address=SOAPData[i].Address;
      state=SOAPData[i].State;
      gender=SOAPData[i].Gender;
      dob=SOAPData[i].Dateofbirth;
      console.log(firstname+','+lastName+','+address+','+state+','+gender+','+dob);
      if (subname=="Subscriber"){memberidref=sub_id+"00";}
     if(subname=="Spouse"){memberidref=sub_id+"01"}
      //if(subname=="Child"){memberidref=sub_id+"01"}
      console.log(memberidref);
      SOAPDatanode.push({
        "sub_node":SOAPData[i].subscriber,
         "Account_node":SOAPData[i].Account,
         "Benefit_Plan_node":SOAPData[i].Benefit_Plan,
         "Firstname_node":SOAPData[i].Firstname,
         "lastname_node":SOAPData[i].lastname,
         "Dateofbirth_node":SOAPData[i].Dateofbirth,
         "Gender_node":SOAPData[i].Gender,
         "Address_node":SOAPData[i].Address,
         "State_node":SOAPData[i].State,
         "MemberID_node":memberidref,
         });
         console.log(SOAPDatanode);
         //let firstnameconcat="firstname"+i;
         arrayforitrate.push({"firstname":firstname,"lastName":lastName,"dob":dob,"gender":gender,"address":address,"memberid":memberidref});
         
         console.log(arrayforitrate);
         

         console.log(subname);
         if (subname != "Spouse") { continue; }
         console.log("comin");
         console.log(SOAPDatanode);
         
         member_id=await soapcall.spousesoapUI(arrayforitrate,accHCCID,beneHCCID,zipode,statecode,SSN,sub_id);
      }
    }


      //console.log(SOAPDatanode);
      return{
        SOAPDatanode
      }

   } 

module.exports = {
  getAccountNames, getBenefitplans,getdatafromSoap
}