const express = require('express');
const path = require('path');
const fs = require('fs').promises;
const app = express();
const cors = require("cors");
const port = 4000;
const router = express.Router();
var bodyParser = require('body-parser');

//Json Support
app.use(express.json());

// Encoder
app.use(
  express.urlencoded({
    extended: true,
  })
);

//background 
app.use('/assets', express.static('view/assets'));

//Cross Origin Support
var corsOptions = {
  origin: "http://localhost:4000" 
};
app.use(cors(corsOptions));

/* Error handler middleware */
app.use((err, req, res, next) => {
  const statusCode = err.statusCode || 500;
  console.error(err.message, err.stack);
  res.status(statusCode).json({ message: err.message });
  return;
});

// Service Files Import
const serviceCall = require('./api/services');
const jsonObj = require('./MemberData.json');

// API GET ENDPOINT
app.get('/AccountName', async function(req, res) {
  try {
    
      let Columndata = await serviceCall.getAccountNames();
      res.json(Columndata); 

  } catch (err) {
    console.error(`Error while getting Account Name `, err.message);
  }
});
app.get('/memberid', async function(req, res) {
  try {
    
      let Columndata = await serviceCall.getmemberid();
      res.json(Columndata); 

  } catch (err) {
    console.error(`Error while getting Account Name `, err.message);
  }
});

// API GET JSON ENDPOINT
app.get('/jsonData', async function(req, res) {
  try {
      let Columndata = jsonObj;
      res.json(Columndata);
  } catch (err) {
    console.error(`Error while getting Account Name `, err.message);
  }
});

//Get Account Name and Benefit plans
app.post('/PostACCName', async function(req, res) {
  try{
    let accName = await req.body.accName;
    //console.log(accName)
    let getbenefitArr = await serviceCall.getBenefitplans(accName); 
    res.status(200).send({getbenefitArr});//
    // res.json({message:"ok"});
  }
  catch (err) {
    console.error(`Error while getting Account Name `, err.message);
  }
});

//to Create MemberID
app.post('/soapResponse', async function(req, res) {
  try{
    let soapdata = await req.body.soap;
    let subtype=await req.body.subtype;
    //console.log(subtype)
    let noderesponse = await serviceCall.getdatafromSoap(soapdata,subtype); 
    //console.log("done");
    res.status(200).send({noderesponse});//
    // res.json({message:"ok"});
  }
  catch (err) {
    console.error(`Error while getting Account Name `, err.message);
  }
});
//HomePage
app.get('/home', function (req, res) {
  res.sendFile(path.join(__dirname, '/view/Home.html'));
})
//HomePage
app.get('/Proclaim', function (req, res) {
  res.sendFile(path.join(__dirname, '/view/claimCreation.html'));
})

//Register page
app.get('/register', function (req, res) {
    res.sendFile(path.join(__dirname, '/view/index.html'));
})

// view Routes Default
app.get('/', function(req, res) {
  res.sendFile(path.join(__dirname, '/view/login.html'));
});

// Port TO listen
app.listen(port);
console.log('Server started at http://localhost:' + port);