//Database CREDENTIALS 
const dbCreds = {
    host     : 'localhost',
    database : 'amit',
    user     : 'root',
    password : 'root',
    port     : '8889'
};

module.exports = dbCreds;
