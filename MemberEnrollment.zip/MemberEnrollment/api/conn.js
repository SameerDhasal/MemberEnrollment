//DATABASE CONNECTIONS 
var mysql = require('mysql');
const dbCreds = require("./db");

var connection = mysql.createConnection({
    host     : dbCreds.host,
    database : dbCreds.database,
    user     : dbCreds.user,
    password : dbCreds.password,
    port     : dbCreds.port
});

module.exports = connection;


// async function getEmployee (empId) {
//     let conn
  
//     try {
//       conn = await oracledb.getConnection(dbCreds)
  
//       const result = await conn.execute(
//         'select * from employees where employee_id = :id',
//         [empId]
//       )
  
//       console.log(result.rows[0])
//     } catch (err) {
//       console.log('Ouch!', err)
//     } finally {
//       if (conn) { // conn assignment worked, need to close
//         await conn.close()
//       }
//     }
//   }
  
//   getEmployee(101)