const oracleconnection = require('./conn');
const oracledb = require('oracledb');
const soapRequest = require('easy-soap-request');


async function SOAPUIConfig(Account, Benefit_Plan, Firstname, lastName, DOB, Gender, address, zipCode) {
    //SOAP Connection
    const memberid = '';
    const url = 'http://100.112.45.153:8181/connector/services/v4/EnrollmentSparse';
    const sampleHeaders = {
        'Content-Type': 'text/xml;charset=UTF-8',
        'soapAction': 'http://healthedge.com/submit',
        'Authorization': 'Basic Y29ubmVjdG9yOkNvbm5lY3RvcjEyMw=='
    };
    (async () => {
        const xml = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:enr="http://www.healthedge.com/connector/schema/enrollmentsparse">
            <soapenv:Header/>
        <soapenv:Body>
         <NS1:enrollment xmlns:NS1="http://www.healthedge.com/connector/schema/enrollmentsparse">
            <actionMode>SPARSE</actionMode>
            <cascadeTerms>false</cascadeTerms>
    <subscription>
       <!-- <hccIdentifier>20020725002</hccIdentifier> -->
       <subscriptionUDTList>
          <listMode>DEFAULT</listMode>
       </subscriptionUDTList>
       <accountMatchData>
          <accountHccIdentifier>
             <accountHccIdentificationNumber>TEST</accountHccIdentificationNumber>
          </accountHccIdentifier>
       </accountMatchData>
                           <informationSourceCode>
          <codeSetName>InformationSource</codeSetName>
          <codeEntry>4</codeEntry>
<!--               <shortName>Claim</shortName>-->
       </informationSourceCode>  
       <claimReviewList>
          <listMode>DEFAULT</listMode>
       </claimReviewList>     
    </subscription>

    <member>
       <maintenanceTypeCode>CREATE</maintenanceTypeCode>
       <memberIsSubscriber>1</memberIsSubscriber>
      <!-- <hccIdentifier>20020725002-00</hccIdentifier> -->
       <individual>
          <genderCode>${Gender}</genderCode>
          <birthDate>${DOB}</birthDate>
          <primaryName>
             <lastName>${lastName}</lastName>
             <firstName>${Firstname}</firstName>
<!--                  <middleName/>-->
<!--                  <nameSuffixList>-->
<!--                     <listMode>REPLACE</listMode>-->
<!--                  </nameSuffixList>-->
          </primaryName>
          <languages>
             <language>
                <primaryLanguage>1</primaryLanguage>
                <languageDomainCode>
                   <codeEntry>EN</codeEntry>
                </languageDomainCode>
             </language>
          </languages>
       </individual>
       <physicalAddress>
          <listMode>DEFAULT</listMode>
          <memberPhysicalAddress>
             <addressInfo>
                <postalAddress>
                   <address>${address}</address>
                   <stateCode></stateCode>
                   <zipCode>${zipCode}</zipCode>
                   <cityName>Burlington</cityName>
                   <ignoreAddressCheck>true</ignoreAddressCheck>
                </postalAddress>
                <addressPhoneList>
                   <listMode>REPLACE</listMode>
                   <telephoneNumber>
                      <phoneAreaCode>301</phoneAreaCode>
                      <phoneNumber>1234567</phoneNumber>
                      <individualPhoneTypeCode>
                         <codeEntry>HP</codeEntry>
                      </individualPhoneTypeCode>
                   </telephoneNumber>
                </addressPhoneList>
             </addressInfo>
             <addressTypeCode>
                <codeSetName>IndividualAddressType</codeSetName>
                <codeEntry>2</codeEntry>
             </addressTypeCode>
          </memberPhysicalAddress>
       </physicalAddress>
       <relationshipToSubscriberDefinitionReference>
          <reference>
             <ID>Self</ID>
          </reference>
       </relationshipToSubscriberDefinitionReference>

       <planSelection>
          <startDate>2023-03-01</startDate>
          <benefitPlanMatchData>
             <benefitPlanHccId>TEST_PLAN_MK</benefitPlanHccId>
          </benefitPlanMatchData>
<!--               <healthCoverageMaintenanceCode>CREATE</healthCoverageMaintenanceCode>-->
<!--               <insuranceLineCode>HLT</insuranceLineCode>-->
       </planSelection>

    </member>
 </NS1:enrollment>
</soapenv:Body>
</soapenv:Envelope>
`
const { response } = await soapRequest({ url: url, headers: sampleHeaders, xml: xml });
const { headers, body, statusCode } = response;
console.log(body);
//console.log(response);
memberid=memberidextract(body)

})();
return{
   memberid
}

}
function memberidextract(soapResponse) {
    debugger;
    try {
        var DomParser = require('dom-parser');
        var parser = new DomParser();
        const xmlDocument = parser.parseFromString(soapResponse, "text/xml");
        const member = xmlDocument.getElementsByTagName("memberId")[0];
        const member_id = member.textContent;
        console.log(member_id);
    } catch (e) {
        console.log(e)
    }

    return {
      member_id
  }
  
}
async function getdbvalue(name , value) {

    connection = await oracledb.getConnection({
        user: 'citi_abagchi',
        password: 'U4ggPVAg9PNuJ',
        connectString: '100.112.45.151:1521/CITPDWTT'
    });
    var code;
    const query='';
    if(name=="statecode")
    {
      //statecode
      query = await connection.execute(`SELECT`);
      code = query.rows[0][0];
    }
    if(name=="zipcode")
    {
      //zipcode
      query = await connection.execute(`SELECT`);
      code = query.rows[0][0];
    }
    return {
      code
    }
}
module.exports = {
   SOAPUIConfig, getdbvalue
 }