const oracleconnection = require('./conn');
const oracledb = require('oracledb');
// Get Account Name
async function getAccountNames() {

  connection = await oracledb.getConnection({
    user: 'citi_abagchi',
    password: 'U4ggPVAg9PNuJ',
    connectString: '100.112.45.151:1521/CITPDWTT'
  });
  const Account = await connection.execute(`SELECT 
  AHF."ACCOUNT_NAME"
  FROM PAYOR_DW.ALL_ACCOUNT_HISTORY_FACT AHF
       INNER JOIN PAYOR_DW.DATE_DIMENSION EFFDT ON EFFDT.DATE_KEY = AHF.VERSION_EFF_DATE_KEY
       INNER JOIN PAYOR_DW.DATE_DIMENSION EXPDT ON EXPDT.DATE_KEY = AHF.VERSION_EXP_DATE_KEY
       LEFT OUTER JOIN PAYOR_DW.TAX_ENTITY TEHF ON AHF.TAX_ENTITY_KEY = TEHF.TAX_ENTITY_KEY
       INNER JOIN PAYOR_DW.POSTAL_ADDRESS PA ON PA.POSTAL_ADDRESS_KEY = AHF.ACCOUNT_CORR_ADDRESS_KEY 
       INNER JOIN PAYOR_DW.STATE_CODE SC ON SC.STATE_CODE = PA.STATE_CODE
  WHERE 
  EFFDT.DATE_VALUE   <= SYSDATE
  AND EXPDT.DATE_VALUE > SYSDATE
  `);
  var Acc=Account.rows

  return {
    Acc
   }

}

// Post Account Name and Get Benefit Plans list 
async function getBenefitplans(data) {
  //SQL connections open 
  connection = await oracledb.getConnection({
    user: 'citi_abagchi',
    password: 'U4ggPVAg9PNuJ',
    connectString: '100.112.45.151:1521/CITPDWTT'
  });
  
  const acckey= await connection.execute("SELECT account_key FROM PAYOR_DW.ALL_ACCOUNT_HISTORY_FACT where account_name='"+data+"'");
  var acc1=acckey.rows[0][0];
  const benefit_pan = await connection.execute("SELECT BENEFIT_PLAN_DESC FROM payor_dw.benefit_plan bf JOIN payor_dw.account_plan_select_fact ap ON bf.benefit_plan_key=ap.benefit_plan_key WHERE ap.account_key='"+acc1+"'");  
   var bene=benefit_pan.rows

  const statename=await connection.execute("SELECT SC.STATE_NAME FROM PAYOR_DW.ALL_ACCOUNT_HISTORY_FACT AHF INNER JOIN PAYOR_DW.DATE_DIMENSION EFFDT ON EFFDT.DATE_KEY = AHF.VERSION_EFF_DATE_KEY INNER JOIN PAYOR_DW.DATE_DIMENSION EXPDT ON EXPDT.DATE_KEY = AHF.VERSION_EXP_DATE_KEY LEFT OUTER JOIN PAYOR_DW.TAX_ENTITY TEHF ON AHF.TAX_ENTITY_KEY = TEHF.TAX_ENTITY_KEY INNER JOIN PAYOR_DW.POSTAL_ADDRESS PA ON PA.POSTAL_ADDRESS_KEY = AHF.ACCOUNT_CORR_ADDRESS_KEY INNER JOIN PAYOR_DW.STATE_CODE SC ON SC.STATE_CODE = PA.STATE_CODE WHERE EFFDT.DATE_VALUE   <= SYSDATE AND EXPDT.DATE_VALUE > SYSDATE AND AHF.account_key = '"+acc1+"'");

var state=statename.rows;

  return {
    bene,
    state
   }
  
  }

  async function SoapUI(SOAPData) {
   
    for (var i=1;i<=SOAPData.length;i++)
    {
      SOAPUIConfig(SOAPData[i].Account,SOAPData[i].Benefit_Plan,SOAPData[i].Firstname,SOAPData[i].lastname,SOAPData[i].Dateofbirth,SOAPData[i].Gender,SOAPData[i].Address,SOAPData[i].State,SOAPData[i].zipcode);
    }
   async function SOAPUIConfig(Account,Benefit_Plan,Firstname,lastName,DOB,Gender,address,zipCode)
   {
        //SOAP Connection
        const soapResponse='';
        const soapRequest = require('easy-soap-request');
        const url = 'http://100.112.45.153:8181/connector/services/v4/EnrollmentSparse';
        const sampleHeaders = {
        'Content-Type': 'text/xml;charset=UTF-8',
        'soapAction': 'http://healthedge.com/submit',
        'Authorization': 'Basic Y29ubmVjdG9yOkNvbm5lY3RvcjEyMw=='
        };
    (async () => {
        const xml =`<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:enr="http://www.healthedge.com/connector/schema/enrollmentsparse">
                <soapenv:Header/>
            <soapenv:Body>
             <NS1:enrollment xmlns:NS1="http://www.healthedge.com/connector/schema/enrollmentsparse">
                <actionMode>SPARSE</actionMode>
                <cascadeTerms>false</cascadeTerms>
        <subscription>
           <!-- <hccIdentifier>20020725002</hccIdentifier> -->
           <subscriptionUDTList>
              <listMode>DEFAULT</listMode>
           </subscriptionUDTList>
           <accountMatchData>
              <accountHccIdentifier>
                 <accountHccIdentificationNumber>TEST</accountHccIdentificationNumber>
              </accountHccIdentifier>
           </accountMatchData>
                               <informationSourceCode>
              <codeSetName>InformationSource</codeSetName>
              <codeEntry>4</codeEntry>
  <!--               <shortName>Claim</shortName>-->
           </informationSourceCode>  
           <claimReviewList>
              <listMode>DEFAULT</listMode>
           </claimReviewList>     
        </subscription>
  
        <member>
           <maintenanceTypeCode>CREATE</maintenanceTypeCode>
           <memberIsSubscriber>1</memberIsSubscriber>
          <!-- <hccIdentifier>20020725002-00</hccIdentifier> -->
           <individual>
              <genderCode>${Gender}</genderCode>
              <birthDate>${DOB}</birthDate>
              <primaryName>
                 <lastName>${lastName}</lastName>
                 <firstName>${Firstname}</firstName>
  <!--                  <middleName/>-->
  <!--                  <nameSuffixList>-->
  <!--                     <listMode>REPLACE</listMode>-->
  <!--                  </nameSuffixList>-->
              </primaryName>
              <languages>
                 <language>
                    <primaryLanguage>1</primaryLanguage>
                    <languageDomainCode>
                       <codeEntry>EN</codeEntry>
                    </languageDomainCode>
                 </language>
              </languages>
           </individual>
           <physicalAddress>
              <listMode>DEFAULT</listMode>
              <memberPhysicalAddress>
                 <addressInfo>
                    <postalAddress>
                       <address>${address}</address>
                       <stateCode></stateCode>
                       <zipCode>${zipCode}</zipCode>
                       <cityName>Burlington</cityName>
                       <ignoreAddressCheck>true</ignoreAddressCheck>
                    </postalAddress>
                    <addressPhoneList>
                       <listMode>REPLACE</listMode>
                       <telephoneNumber>
                          <phoneAreaCode>301</phoneAreaCode>
                          <phoneNumber>1234567</phoneNumber>
                          <individualPhoneTypeCode>
                             <codeEntry>HP</codeEntry>
                          </individualPhoneTypeCode>
                       </telephoneNumber>
                    </addressPhoneList>
                 </addressInfo>
                 <addressTypeCode>
                    <codeSetName>IndividualAddressType</codeSetName>
                    <codeEntry>2</codeEntry>
                 </addressTypeCode>
              </memberPhysicalAddress>
           </physicalAddress>
           <relationshipToSubscriberDefinitionReference>
              <reference>
                 <ID>Self</ID>
              </reference>
           </relationshipToSubscriberDefinitionReference>
  
           <planSelection>
              <startDate>2023-03-01</startDate>
              <benefitPlanMatchData>
                 <benefitPlanHccId>TEST_PLAN_MK</benefitPlanHccId>
              </benefitPlanMatchData>
  <!--               <healthCoverageMaintenanceCode>CREATE</healthCoverageMaintenanceCode>-->
  <!--               <insuranceLineCode>HLT</insuranceLineCode>-->
           </planSelection>
  
        </member>
     </NS1:enrollment>
  </soapenv:Body>
  </soapenv:Envelope>
  `
  const { response } = await soapRequest({ url: url, headers: sampleHeaders, xml: xml });
  const { headers, body, statusCode } = response;
  console.log(headers);
  console.log(body);
  console.log(statusCode);
  soapResponse=response;
})();
}
const parser = new DOMParser();
const xmlDocument = parser.parseFromString(soapResponse, "text/xml");
const member = xmlDocument.getElementsByTagName("memberId")[0];
const member_id = member.textContent;
console.log(member_id); 
    
}

module.exports = {
  getAccountNames, getBenefitplans
}