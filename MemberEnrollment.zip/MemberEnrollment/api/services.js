const oracleconnection = require('./conn');
const oracledb = require('oracledb');
// Get Account Name
async function getAccountNames() {

  connection = await oracledb.getConnection({
    user: 'citi_abagchi',
    password: 'U4ggPVAg9PNuJ',
    connectString: '100.112.45.151:1521/CITPDWTT'
  });
  const Account = await connection.execute(`SELECT 
  AHF."ACCOUNT_NAME"
  FROM PAYOR_DW.ALL_ACCOUNT_HISTORY_FACT AHF
       INNER JOIN PAYOR_DW.DATE_DIMENSION EFFDT ON EFFDT.DATE_KEY = AHF.VERSION_EFF_DATE_KEY
       INNER JOIN PAYOR_DW.DATE_DIMENSION EXPDT ON EXPDT.DATE_KEY = AHF.VERSION_EXP_DATE_KEY
       LEFT OUTER JOIN PAYOR_DW.TAX_ENTITY TEHF ON AHF.TAX_ENTITY_KEY = TEHF.TAX_ENTITY_KEY
       INNER JOIN PAYOR_DW.POSTAL_ADDRESS PA ON PA.POSTAL_ADDRESS_KEY = AHF.ACCOUNT_CORR_ADDRESS_KEY 
       INNER JOIN PAYOR_DW.STATE_CODE SC ON SC.STATE_CODE = PA.STATE_CODE
  WHERE 
  EFFDT.DATE_VALUE   <= SYSDATE
  AND EXPDT.DATE_VALUE > SYSDATE
  `);
  var Acc=Account.rows

  return {
    Acc
   }

}

// Post Account Name and Get Benefit Plans list 
async function getBenefitplans(data) {
  //SQL connections open 
  connection = await oracledb.getConnection({
    user: 'citi_abagchi',
    password: 'U4ggPVAg9PNuJ',
    connectString: '100.112.45.151:1521/CITPDWTT'
  });
  
  const acckey= await connection.execute("SELECT account_key FROM PAYOR_DW.ALL_ACCOUNT_HISTORY_FACT where account_name='"+data+"'");
  var acc1=acckey.rows[0][0];
  const benefit_pan = await connection.execute("SELECT BENEFIT_PLAN_DESC FROM payor_dw.benefit_plan bf JOIN payor_dw.account_plan_select_fact ap ON bf.benefit_plan_key=ap.benefit_plan_key WHERE ap.account_key='"+acc1+"'");  
   var bene=benefit_pan.rows

  const statename=await connection.execute("SELECT SC.STATE_NAME FROM PAYOR_DW.ALL_ACCOUNT_HISTORY_FACT AHF INNER JOIN PAYOR_DW.DATE_DIMENSION EFFDT ON EFFDT.DATE_KEY = AHF.VERSION_EFF_DATE_KEY INNER JOIN PAYOR_DW.DATE_DIMENSION EXPDT ON EXPDT.DATE_KEY = AHF.VERSION_EXP_DATE_KEY LEFT OUTER JOIN PAYOR_DW.TAX_ENTITY TEHF ON AHF.TAX_ENTITY_KEY = TEHF.TAX_ENTITY_KEY INNER JOIN PAYOR_DW.POSTAL_ADDRESS PA ON PA.POSTAL_ADDRESS_KEY = AHF.ACCOUNT_CORR_ADDRESS_KEY INNER JOIN PAYOR_DW.STATE_CODE SC ON SC.STATE_CODE = PA.STATE_CODE WHERE EFFDT.DATE_VALUE   <= SYSDATE AND EXPDT.DATE_VALUE > SYSDATE AND AHF.account_key = '"+acc1+"'");

var state=statename.rows;

  return {
    bene,
    state
   }
  
  }

  async function getdatafromSoap(SOAPData) {
   const member_id='';
   var statecode='';
   var zipode='';
   var SOAPDatanode = [];
    for (var i=1;i<=SOAPData.length;i++)
    {
      statecode=await soapcall.getdbvalue("statecode",SOAPData[i].State)
      zipode = await soapcall.getdbvalue("zipcode",SOAPData[i].State)
      member_id=await soapcall.SOAPUIConfig(SOAPData[i].Account,SOAPData[i].Benefit_Plan,SOAPData[i].Firstname,SOAPData[i].lastname,SOAPData[i].Dateofbirth,SOAPData[i].Gender,SOAPData[i].Address,SOAPData[i].State,SOAPData[i].zipcode);
      SOAPDatanode.push({
         "Account":SOAPData[i].Account,
         "Benefit_Plan":SOAPData[i].Benefit_Plan,
         "Firstname":SOAPData[i].Firstname,
         "lastname":SOAPData[i].lastname,
         "Dateofbirth":OAPData[i].Dateofbirth,
         "Gender":SOAPData[i].Gender,
         "Address":SOAPData[i].Address,
         "State":SOAPData[i].State,
         "MemberID":member_id,
         });
      }

      return{
        SOAPDatanode
      }

   } 

module.exports = {
  getAccountNames, getBenefitplans,getdatafromSoap
}